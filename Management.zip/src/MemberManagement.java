import java.util.InputMismatchException;
import java.util.Scanner;
 
 
public class MemberManagement {
   
    public static void main(String[] args) {
       
        MemberProc mm = new MemberProc();
           
        while (true) {
            System.out.println();
            System.out.println("============== ★사원 관리 프로그램 ★ =====================");
            System.out.println("1. 사원목록");         
            System.out.println("2. 사원등록   3. 사원삭제   4. 사원정보 수정");
            System.out.println("5. 종료");
            System.out.println("============== aaaaaaaaaaaaaaaaaa ==============");
            System.out.print("메뉴 번호를 입력하시요 : ");
           
            Scanner scn = new Scanner(System.in);
            int num=0;
            try {
                num = scn.nextInt();
                if(!(num>0 && num<6)){ //1~5만 입력하게끔만듬
                    throw new InputMismatchException();
                }
            } catch (InputMismatchException e) {
                System.out.println("입력된 값이 잘못되었습니다. [1~5] 메뉴늘 선택해주세요!");
            }
           
            switch (num) {
            case 1:
                mm.showMemberList();//사원목록         
                break;
            case 2:
                mm.insertMember(); //사원 등록
                break;
            case 3:
                mm.deleteMember(); //사원 삭제             
                break;
            case 4:
                mm.updateMember(); //사원 수정
                break;
            case 5:
                System.out.println("프로그램을 종료합니다.");
                System.exit(0); //프로그램 종료
                   
            }
        }
       
    }
   
}
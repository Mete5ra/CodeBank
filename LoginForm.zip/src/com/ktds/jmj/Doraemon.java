package com.ktds.jmj;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Doraemon
 */
public class Doraemon extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Doraemon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String gender = request.getParameter("gender");
		String id = request.getParameter("ID");
		String password = request.getParameter("pwd");
		String name = request.getParameter("Name");
		String email = request.getParameter("email");
		String tel = request.getParameter("phoneNumber");
		String receive = request.getParameter("receive");
		String teltype = request.getParameter("TelType");
		String[] checkhobby = request.getParameterValues("hobby");
		
		RequestDispatcher rd = request.getRequestDispatcher("/program.jsp");
		request.setAttribute("gender", gender);
		request.setAttribute("ID", id);
		request.setAttribute("pwd", password);
		request.setAttribute("Name", name);
		request.setAttribute("email", email);
		request.setAttribute("phoneNumber", tel);
		request.setAttribute("receive", receive);
		request.setAttribute("checkhobby", checkhobby);
		request.setAttribute("TelType", teltype);
		
		rd.forward(request, response);	
	}

}
